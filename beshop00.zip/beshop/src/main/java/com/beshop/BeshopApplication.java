package com.beshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeshopApplication.class, args);
	}

}
