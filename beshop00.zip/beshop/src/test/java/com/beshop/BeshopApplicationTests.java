package com.beshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
